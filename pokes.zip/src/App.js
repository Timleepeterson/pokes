import './App.css';
import Pokes from './components/Pokes';
function App() {
  return (
    <div className="App">
      <Pokes />
    </div>
  );
}

export default App;
